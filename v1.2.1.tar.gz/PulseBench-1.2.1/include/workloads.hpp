#pragma once
void register_builtin_workloads();
